# db-capstone-project
Below is a list of all the reports (zoomed in for better view)

1. Customer Sales:
   
   <img width="715" alt="image" src="https://github.com/vibhats30/db-capstone-project/assets/53223858/704af42d-3966-4de4-a8fa-61571d08e7fd">
   


2. Profit Chart:
 
   <img width="367" alt="image" src="https://github.com/vibhats30/db-capstone-project/assets/53223858/9312f0db-d0b5-47ba-be2e-6821b1b335ff">


3. Sales Bubble Chart

   <img width="628" alt="image" src="https://github.com/vibhats30/db-capstone-project/assets/53223858/e90620f9-7d87-4ad8-9020-85dc12e2cdd1">

4. Cuisine Sales and Profits
   <img width="902" alt="image" src="https://github.com/vibhats30/db-capstone-project/assets/53223858/ae2d82aa-cecc-424b-a3cf-74d9f5c30cb5">


5.  Dashboard
   
![image](https://github.com/vibhats30/db-capstone-project/assets/53223858/18b0966a-40bd-4be2-aed3-73f4e0210288)
